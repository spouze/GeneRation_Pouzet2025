## COPY AND BUILT ON SCRIPT 210.
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) # Set working directory where the file is.
# getwd()
source("GeneRation_Fun_v1.R")
source("GeneRation_DataAnalysis_FUN.R")

#################################################################
### EXTRACT DATA FROM SIMULATIONS
#################################################################
# HERE, we will use 2 simulations per topologies, ie, 6 simulations.

## Based on SCRIPT 022
burnin=F # is TRUE if two successive adaptations
simus_folder_path = "SIMULATIONS/" # ends with slash
batch_name = "TUTO_SIMUS"
all_batch_simus = list.files(paste(simus_folder_path))
# Load the first one to estimate parameters
simu_id = all_batch_simus[1]
simu = LoadSimu(paste0(simus_folder_path, simu_id, "/"))
#fit1000 = simu[[1]]$MFit[1000]
generations = length(simu[[1]]$MFit)
if (burnin){generations = generations*2}
nb_simus_total = length(all_batch_simus)

# Start data collection  ########################################
# CREATE RECEPTACLES #############################
# 1. Create empty dataframe that will receive the fitness across generations
store_Fits_BATCH = data.frame(matrix(ncol=generations+2, nrow = nb_simus_total))
colnames(store_Fits_BATCH) = c("id", "topo", paste0("gen", 1:generations))
# 2. Create empty dataframe that will receive the last line of each simu w params
store_Last_BATCH = data.frame(matrix(ncol=263+10+10+2, nrow = nb_simus_total))
colnames(store_Last_BATCH) = c("id", "topo", colnames(simu[[1]]), paste0("FIT_OPT", 1:10), paste0("FIT_STR",1:10))
# 3. Create empty dataframe that will receive just the fitness of each simu
store_JustLastFit_BATCH = data.frame(matrix(ncol=1+2, nrow = nb_simus_total))
colnames(store_JustLastFit_BATCH) = c("id", "topo", "Fitness of pop")
# START COLLECT #############################
for (simu_id in all_batch_simus) {
  simuE1 = LoadSimu(paste0(simus_folder_path, simu_id, "/"))
  FitE1  = simuE1[[1]]$MFit
  i = match(simu_id, all_batch_simus)
  # 1. Save the last line in store_Last
  store_Last_BATCH[i,] = c(simu_id, 
                           substr(simu_id, 13,18), 
                           simuE1[[1]][1000,],
                           simuE1[[5]]$FITNESS_OPTIMUM,
                           simuE1[[5]]$FITNESS_STRENGTH
  )
  # 2. Save just the last fitness of the pop (at generation 1000, even if burnin)
  store_JustLastFit_BATCH[i,] = c(simu_id, 
                                  substr(simu_id, 13,18),
                                  simuE1[[1]][1000,]$MFit)
  # 3. Save the fitnesses in store_Fitnesses
  if (burnin) {
    simuE2 = LoadSimu(paste0(folder_name, "/", simu_id, "/", simu_id, ".burnin/"))
    FitE2  = simuE2[[1]]$MFit
    store_Fits_BATCH[i,] = c(simu_id, 
                             substr(simu_id, 13,18),
                             FitE1, FitE2) # IF BURNIN
  }else{
    store_Fits_BATCH[i,] = c(simu_id, 
                             substr(simu_id, 13,18), 
                             FitE1)
  }
  cat(paste0(i,".")) #Signal to user that this is done.
}
# SAVE ON DISK #############################
destination_folder = "Extracted_data/"
if(burnin){burninornot = "_burnin"}else{burninornot=""}
write.csv(store_Last_BATCH       , file = paste0(destination_folder, "storeLasts_",        batch_name, burninornot))
write.csv(store_Fits_BATCH       , file = paste0(destination_folder, "storeFits_",         batch_name, burninornot))
write.csv(store_JustLastFit_BATCH, file = paste0(destination_folder, "storeJustLastFits_", batch_name, burninornot))


#################################################################
### LOAD EXTRACTED DATA
#################################################################
folder = "Extracted_data/"
list.files(folder, pattern = "storeFits")
batch = "TUTO_SIMUS"

three_files = list.files(folder, pattern = paste0(batch, "$"))

storeFits         = read.csv(paste0(folder, three_files[1]))
storeJustLastFits = read.csv(paste0(folder, three_files[2]))
storeLasts        = read.csv(paste0(folder, three_files[3]))

### SPLIT
storeFits_HIGHCO = storeFits[storeFits$topo=="HIGHCO",]
storeFits_RANDOM = storeFits[storeFits$topo=="RANDOM",]
storeFits_SCALEF = storeFits[storeFits$topo=="SCALEF",]

storeJustLastFits_HIGHCO = storeJustLastFits[storeFits$topo=="HIGHCO",]
storeJustLastFits_RANDOM = storeJustLastFits[storeFits$topo=="RANDOM",]
storeJustLastFits_SCALEF = storeJustLastFits[storeFits$topo=="SCALEF",]

storeLasts_HIGHCO = storeLasts[storeLasts$topo=="HIGHCO",]
storeLasts_RANDOM = storeLasts[storeLasts$topo=="RANDOM",]
storeLasts_SCALEF = storeLasts[storeLasts$topo=="SCALEF",]

#################################################################
### Successful simulations
#################################################################
## If I want a least 200...
# sum(storeJustLastFits_HIGHCO$Fitness.of.pop>0.9)
# sum(storeJustLastFits_RANDOM$Fitness.of.pop>0.9)
# sum(storeJustLastFits_SCALEF$Fitness.of.pop>0.9)
# which(storeJustLastFits_HIGHCO$Fitness.of.pop>0.9)

dream_Fits_HIGHCO = storeFits_HIGHCO[which(storeJustLastFits_HIGHCO$Fitness.of.pop>0.9),]
dream_Fits_RANDOM = storeFits_RANDOM[which(storeJustLastFits_RANDOM$Fitness.of.pop>0.9),]
dream_Fits_SCALEF = storeFits_SCALEF[which(storeJustLastFits_SCALEF$Fitness.of.pop>0.9),]

dream_Lasts_HIGHCO = storeLasts_HIGHCO[which(storeJustLastFits_HIGHCO$Fitness.of.pop>0.9),]
dream_Lasts_RANDOM = storeLasts_RANDOM[which(storeJustLastFits_RANDOM$Fitness.of.pop>0.9),]
dream_Lasts_SCALEF = storeLasts_SCALEF[which(storeJustLastFits_SCALEF$Fitness.of.pop>0.9),]

# round(x, 2)
cat(paste0(
  "HIGHCO : ", nrow(dream_Lasts_HIGHCO), " sucessful ", "out of ", nrow(storeLasts_HIGHCO), ", ie ", round(nrow(dream_Lasts_HIGHCO)/nrow(storeLasts_HIGHCO)*100, 0), "%\n", 
  "RANDOM : ", nrow(dream_Lasts_RANDOM), " sucessful ", "out of ", nrow(storeLasts_RANDOM), ", ie ", round(nrow(dream_Lasts_RANDOM)/nrow(storeLasts_RANDOM)*100, 0), "%\n",
  "SCALEF : ", nrow(dream_Lasts_SCALEF), " sucessful ", "out of ", nrow(storeLasts_SCALEF), ", ie ", round(nrow(dream_Lasts_SCALEF)/nrow(storeLasts_SCALEF)*100, 0), "%\n"
           ))

################################################################
################################################################
################################################################
## PLOT FIGURE 3 - Adaptation lines
################################################################
################################################################
################################################################
# dev.off()
# plot(NA, xlim=c(0,1000), ylim=c(0,1), ylab="Fitness", xlab="Generations", main = batch)
# lines(colMeans(dream_Fits_HIGHCO[,-c(1,2,3)]), col=topocolors[1])
# lines(colMeans(dream_Fits_RANDOM[,-c(1,2,3)]), col=topocolors[2])
# lines(colMeans(dream_Fits_SCALEF[,-c(1,2,3)]), col=topocolors[3])

### SCRIPT 103
generations = 1000
chosentopologies = topologies
colrs = topocolors
envcols = c("#B89D6E", "#6EA9B8")
onlysuccessfuls = T # ON PREND QUE LES SUCCESSFUL LA.
if (onlysuccessfuls){prefix="dream_Fits_"}else{prefix="storeFits_"}

# width = 10 # unit is cm
# height =  20 # unit is cm
# { # ALL PDF
#   pdf(file = paste0(folder, "/outputs/Rplot", format(Sys.time(), "%Y%m%d%H%M%S"), "_", batch,".pdf"), 
#       width = width/cmtoin, height = height/cmtoin)
  
  { # LAUNCH WHOLE FIGURE
    
    par(mfrow=c(2,1))
    for (onlysuccessfuls in c(F,T)){
      if (onlysuccessfuls){prefix="dream_Fits_"}else{prefix="storeFits_"}
      if (onlysuccessfuls){pretit=" - success"}else{pretit=" - All"}
      N = c()
      par(mgp=c(2.1, 1, 0)) # default c(3, 1, 0)
      main = batch
      
      plot(NA, xlim=c(0,generations), ylim=c(0,1), xlab="Generations", ylab="Population Fitness", 
           main = paste0(main, pretit), bty ='n') #bty ='n' removes the plot
      abline(v=1000, col="grey", lty="dashed") ; 
      abline(h=c(0.5, 1), col="grey", lwd=.5)
      # Q1 and Q3 polygon
      for (topo in chosentopologies) {
        store_Fits_XXXXXX = get(paste0(prefix,topo))[,-c(1:3)]
        colr = colrs[match(topo, topologies)] ; col2 = "grey"
        q1 = apply(store_Fits_XXXXXX[,1:generations], 2, function(x) quantile(x, probs = 0.25, na.rm = TRUE))
        q2 = apply(store_Fits_XXXXXX[,1:generations], 2, function(x) quantile(x, probs = 0.75, na.rm = TRUE)) # Q3 genre
        polygon(c(1:generations, generations:1), c(q1, rev(q2)), col=adjustcolor(colr, .2)
                , border = NA #adjustcolor(colr, .5)
        )}
      # MEDIANs
      for (topo in chosentopologies) {
        store_Fits_XXXXXX = get(paste0(prefix,topo))[,-c(1:3)]
        colr = colrs[match(topo, topologies)]
        # colr = "black"
        qmed = apply(store_Fits_XXXXXX[,1:generations], 2, function(x) quantile(x, probs = 0.5, na.rm = TRUE))
        lines(1:generations, qmed, col=colr, lwd=2)
        N = c(N, nrow(store_Fits_XXXXXX))
      }
      # LEGEND
      if(onlysuccessfuls){yposition=0.2}else{yposition=0.2}
      text(x = 1000, y = yposition, # "topright", # x=800, y=.4, # 0.85 for successful, 0.45 for all simus
           c(paste0("Highly-connected (N=", N[1], ")"),
             paste0("\n\n\nRandom (N=", N[2], ")"),
             paste0("\n\n\n\n\n\nScale-free (N=", N[3],")")), 
           col=c("red3", "green4", "blue3"), bty="n", pos = 2) # pos 2 = aligned to the right
    } #for (onlysuccessfuls in c(T,F)){
  } # LAUNCH WHOLE FIGURE
  dev.off() ;  # for the end of the PDF
#  } # ALL PDF



  ################################################################
  ################################################################
  ################################################################
  ## PLOT FIGURE 2 (E,J,O) - Network distributions
  ################################################################
  ################################################################
  ################################################################
# BASED ON SCRIPT 060

dream_SET = rbind(
  dream_Lasts_HIGHCO,
  dream_Lasts_RANDOM,
  dream_Lasts_SCALEF)

#Create master dataframe
SUPER_Wdegree_df = data.frame(matrix(NA, ncol = 8, nrow = 10*nrow(dream_SET)))
colnames(SUPER_Wdegree_df)=c("line", "id", "topo", "gene", 
                             "indegree", "outdregree", "inout_cross", "inout_add")
for (line in 1:nrow(dream_SET)){
  Wmean = WConvert(IndivRecap(dream_SET, line = line, clean = T, cleanthresh = 0.01)$indclean)
  id    = dream_SET[line,]$id
  topo  = dream_SET[line,]$topo
  for (gene in 1:10) {
    #ext pour "extended"
    degree_ext_in    = which(Wmean[gene,1:10]!=0)
    degree_ext_out   = which(Wmean[,gene]!=0)
    degree_ext_inout = unique(c(degree_ext_in, degree_ext_out)) #???
    degree_in    = length(degree_ext_in   )
    degree_out   = length(degree_ext_out  )
    degree_inout = length(degree_ext_inout)
    # Remplit le master dataframe
    SUPER_Wdegree_df[(((line-1)*10)+gene),] = c(line, id, topo, 
                                                gene, 
                                                degree_in, degree_out, degree_inout, 
                                                (degree_in + degree_out))
  } ; cat(paste0(line,".")) #just for notice
}
############### PLOT DEGREES #####################
# { # ALL PDF
#   width= 10 ; height = 20
#   pdf(file = paste0(folder, "/outputs/Rplot", format(Sys.time(), "%Y%m%d%H%M%S"), "_", batch,".pdf"), 
#       width = width/cmtoin, height = height/cmtoin)
  colrs = topocolors
  par(mfrow=c(3,1))
  for (topo in topologies){
    table(SUPER_Wdegree_df[which(SUPER_Wdegree_df$topo==topo),]$degree_inout)
    occurences = as.data.frame(table(SUPER_Wdegree_df[which(SUPER_Wdegree_df$topo==topo),]$inout_add), stringsAsFactors = F)
    occurences$Var1=as.integer(occurences$Var1)
    if (min(occurences$Var1)>0)  {for (i in 0:(min(occurences$Var1)-1)) {occurences = rbind(occurences, c(i,0))}}
    if (max(occurences$Var1)<18) {for (i in (max(occurences$Var1)+1):18){occurences = rbind(occurences, c(i,0))}}
    occurences = occurences[order(occurences$Var1),]
    barplot(occurences$Freq/sum(occurences$Freq), 
            col=c("grey",rep(colrs[match(topo, topologies)],20)), main = topo, 
            names.arg = occurences$Var1, ylim=c(0,0.36),
            ylab="Frequency", xlab="Degree (connexions per gene)")
  }
  dev.off()
#} ; # end PDF
#resetplot()

#################################################################
#################################################################
#################################################################
### Carry out tests
#################################################################
#################################################################
#################################################################

# Let's take only the first 100 to start with
n = 100
dream_Lasts_HIGHCO = dream_Lasts_HIGHCO[c(1:n),]
dream_Lasts_RANDOM = dream_Lasts_RANDOM[c(1:n),]
dream_Lasts_SCALEF = dream_Lasts_SCALEF[c(1:n),]

# Les tests sont : du + ou - 0.5, seulement pour les COD et REG (no DUP)
# Par simulation on va faire genre 
# BASED ON SCRIPT 073
str(dream_SET)

{# PARAMETERS TO CARRY OUT THE TESTS
  simu_nb_start = 1  
  simu_nb_stop  = nrow(dream_SET)
  simu_seq = simu_nb_start:simu_nb_stop
  simu_nb = length(simu_seq)
  
  dup_muteff_to_test = c(1:5)
  del_muteff_to_test = c(1:5)
  reg_muteff_to_test = seq(-1,1,0.1) # c(0.5, -0.5) #seq is 21 seq(-1,1,0.1)
  cod_muteff_to_test = seq(-1,1,0.1) # c(0.5, -0.5)
  
  number_of_test_per_muttype = 20
  
  number_of_batches = 1 # nombre de fichiers
  start_batch = 1
  end_batch = number_of_batches
  batch_seq = start_batch:end_batch
  
  destination_folder = folder
  check_folder_exists(destination_folder) # Check if the folder exists
} ######################################

## START TESTS ##################################################################
for (batch_x in batch_seq){ # start all batches
  # INIT :
  lines_number = number_of_test_per_muttype*(
    length(na.omit(reg_muteff_to_test))+
      length(na.omit(cod_muteff_to_test))+
      length(na.omit(dup_muteff_to_test))+
      length(na.omit(del_muteff_to_test))
  )*simu_nb
  
  allmutations = data.frame(matrix(ncol = length(cnames), nrow = 0))
  colnames(allmutations)=cnames
  very_init_time = Sys.time()
  counter=0
  
  for (selected_simu in simu_seq){ # start batch x
    counter=counter+1
    ind = IndivRecap(storeLasts_set = dream_SET, line = selected_simu, clean = F)
    cat(paste0(sprintf("%04d", counter), " / ", sprintf("%04d", simu_nb), " - "))
    init_time = Sys.time()
    for (test_number in 1:number_of_test_per_muttype){ # Choose the number of tests for each simu 
      
      # 1. REGULATORY MUTATIONS
      if (is.na(reg_muteff_to_test)){}else{
        allmutreg =  data.frame(matrix(ncol = length(cnames), nrow = 0))
        colnames(allmutreg)=cnames
        for (reg_muteff in reg_muteff_to_test){
          allmutreg = rbind(allmutreg, Mutate_in_new_environment(ind, "REG", reg_muteff = reg_muteff, id = counter))}}
      
      # 2. CODING MUTATIONS
      if (is.na(cod_muteff_to_test)){}else{
        allmutcod =  data.frame(matrix(ncol = length(cnames), nrow = 0))
        colnames(allmutcod)=cnames
        for (cod_muteff in cod_muteff_to_test){
          allmutcod = rbind(allmutcod, Mutate_in_new_environment(ind, "COD", cod_muteff = cod_muteff, id = counter))}}
      
      # 3. GENE DUPLICATIONS
      if (is.na(sum(dup_muteff_to_test))){ # on met la sum() pour pas que ca bug avec if(is.na(1:10)){} 20240417
        allmutdup =  data.frame(matrix(ncol = length(cnames), nrow = 0))
      }else{
        allmutdup =  data.frame(matrix(ncol = length(cnames), nrow = 0))
        colnames(allmutdup)=cnames
        for (dup_number in dup_muteff_to_test){ # because 10 genes
          allmutdup = rbind(allmutdup, Mutate_in_new_environment(ind, "DUP", dupdel_number = dup_number, id = counter))}}
      
      # 4. GENE DELETIONS
      if (is.na(sum(del_muteff_to_test))){
        allmutdel =  data.frame(matrix(ncol = length(cnames), nrow = 0))
      }else{
        allmutdel =  data.frame(matrix(ncol = length(cnames), nrow = 0))
        colnames(allmutdel)=cnames
        for (del_number in del_muteff_to_test){ # because 10 genes
          allmutdel = rbind(allmutdel, Mutate_in_new_environment(ind, "DEL", dupdel_number = del_number, id = counter))}}
      
      allmutations = rbind(allmutations, allmutreg, allmutcod, allmutdup, allmutdel)}
    final_time = Sys.time()
    cat(round(as.numeric(final_time - init_time, units = "secs"),3))
    cat(paste0(" secs.\n"))
  };{
    allmutations$id = 1:nrow(allmutations)
     
    very_final_time = Sys.time()
    cat(paste0("\nTotal time: ", 
               round(as.numeric(very_final_time - very_init_time, units = "mins"),3),
               " minutes.\n"))
  } # end batch x
  ## SAVING :
  write.csv(allmutations, 
            paste0(destination_folder, "allmutations_", format(very_init_time, "%Y%m%d%H%M%S"), "_",  sprintf("%03d",batch_x), "_", batch, ".csv"))

} # end all batches ## END OF "PERFORM TESTS"
####### IT'S OKAY IF THERE ARE MANY WARNINGS.
nrow(allmutations) / nrow(dream_SET)


################################################################
################################################################
################################################################
## PLOT FIGURE 4 - FITNESS EFFECTS
################################################################
################################################################
################################################################
## Based on SCRIPT 115

{## PRE-TREATMENT
  # Rassemble DUP et DEL for easy ploting
  allmutations[allmutations$mut_type=="DEL",]$dupdel_number = -allmutations[allmutations$mut_type=="DEL",]$dupdel_number
  allmutations[allmutations$mut_type=="DEL",]$mut_type = "DUP"
  # Define different classes for effect on fitness.
  effect_class_tresh = rev(c(0.1, 0.01, 0.001, -0.001, -0.01, -0.1))
  effect_class= rev(c("BENEF3", "BENEF2", "BENEF1", "NEUTR", "DELET1", "DELET2", "DELET3"))
  #effect_class_color = rev(c(colorRampPalette(c("#066400","#989797", "#831D01"))(7)))
  effect_class_color = rev(c(colorRampPalette(c("#066400","#BFBFBF", "#831D01"))(7)))
  allmutations$fit_effect <- assign_category(allmutations$fit_delta)
}
####################################################################
## PLOT BARPLOTS EFFECTS ON FITNESS
####################################################################
# width = 34 # unit is cm
# height =  19 # unit is cm
# { # FULL PDF FIGURE
#   pdf(file = paste0("Rplot", format(Sys.time(), "%Y%m%d%H%M%S"), "_", width, "x", height, ".pdf"), 
#       width = width/cmtoin, height = height/cmtoin)
  { # DRAW WHOLE FIGURE
    par(mfrow=c(3,3))
    par(oma = c(5.3, 5.5, 3, 0)) # Outer (overall) MArgin
    par(mar=c(1,0,1.5,0)+0.1) # plot inside MARgins
    draw_box = F #for box("figure", col="forestgreen)
    
    barplot_space_neutr  = 0.14 # default 0.2
    barplot_space_others = 0.03# cannot be NA: has to be 0
    #barplot_space = 0.2 
    barplot_border_color = NA #"white" # default black
    
    plotcounter = 0
    for (topology in c("HIGHCO", "RANDOM", "SCALEF")){
      #topology = "RANDOM"
      #Extract data
      pool_topology = allmutations[allmutations$topology==topology,]
      for (mut_type in c("REG", "COD", "DUP")){
        #mut_type = "REG"
        #Extract data
        plotcounter = plotcounter+1
        pool_mut_type = pool_topology[pool_topology$mut_type==mut_type,]
        #find the right muteff column
        muteff_var = c("reg_muteff", "cod_muteff", "dupdel_number")[match(mut_type, c("REG", "COD", "DUP"))] # was dup_number before
        #Get the different values tested
        muteff_levels = as.numeric(levels(as.factor(pool_mut_type[,muteff_var])))
        # deal with spaces
        barplot_space = rep(barplot_space_others, length(muteff_levels))
        barplot_space[c(which(muteff_levels==0), which(muteff_levels==0)+1)] = c(barplot_space_neutr, barplot_space_neutr)
        #Setup empty dataframe for results
        bilan_pool_muteff = data.frame(matrix(ncol = length(muteff_levels), nrow = length(effect_class)))
        colnames(bilan_pool_muteff) = muteff_levels
        rownames(bilan_pool_muteff) = rev(effect_class)
        #Compute and fill in the dataframe
        for (used_muteff in colnames(bilan_pool_muteff)){ # 0 0.1 0.2 0.3
          pool = pool_mut_type[pool_mut_type[,muteff_var] == used_muteff,]
          for (fit_effect in rownames(bilan_pool_muteff)){ #"NEUTR" "BENEF" "DELET"
            bilan_pool_muteff[fit_effect, used_muteff] = sum(pool$fit_effect == fit_effect)/nrow(pool)  
          }
        }
        cat(paste0(topology, " - ", mut_type))
        bilan_pool_muteff
        
        # Barplots with colored coreders and an extra large black border (2nd barplot)
        coordinates = barplot(as.matrix(bilan_pool_muteff), col=rev(effect_class_color), border = NA, xaxt = "n", yaxt = "n", space = barplot_space)
        barplot(colSums(as.matrix(bilan_pool_muteff)), border = barplot_border_color, add = T, col="NA", xaxt = "n", yaxt = "n", space = barplot_space)
        # Axis (with plotcounter)
        if (sum(plotcounter==c(1,4,7)) == 1){
          #barplot(colSums(as.matrix(bilan_pool_muteff)), border=NA, col=NA, xaxt = "n", add = T)
          axis(2, at = c(0, 0.25, 0.5, 0.75, 1), tick = T, pos = -0.6,
               labels = c(0, "", 0.5, "", 1), cex.axis = 1.5)
        } # adds y axis
        
        decalage_bas = -0.16
        taille_text_gris = 1.5
        talle_nombres_gris = 1.5
        if (sum(plotcounter==c(7,8,9)) == 1){
          #barplot(colSums(as.matrix(bilan_pool_muteff)), border=NA, col=NA, yaxt = "n", add = T)
          if (mut_type == "REG" | mut_type == "COD"){
            axis(1, at = coordinates[c(1, 6, 11, 16, 21)], tick = T, pos = -0.05, #pos empeche que ce soit collé au barplot
                 #labels =c("-1", "","","","", "-0.5", "","","","", "0", "","","","", "+0.5", "","","","", "+1"))}
                 labels =c("-1", "-0.5", "0",  "+0.5","+1"), 
                 cex.axis = talle_nombres_gris)}
          if (mut_type == "REG"){
            axis(1, at = coordinates[c(6)], tick = F, pos = decalage_bas, 
                 labels = c("towards repression"), 
                 cex.axis = taille_text_gris, col.axis = "#808080")
            axis(1, at = coordinates[c(16)], tick = F, pos = decalage_bas, 
                 labels = c("towards activation"), 
                 cex.axis = taille_text_gris, col.axis = "#808080")}
          if (mut_type == "COD"){
            axis(1, at = coordinates[c(6)], tick = F, pos = decalage_bas, 
                 labels = c("towards loss of function"), cex.axis = taille_text_gris, col.axis = "#808080")
            axis(1, at = coordinates[c(16)], tick = F, pos = decalage_bas, 
                 labels = c("towards gain of function"), cex.axis = taille_text_gris, col.axis = "#808080")
          }
          if (mut_type == "DUP"){
            axis(1, at = coordinates[c(1, 4, 6, 8, 11, 16)], tick = T, pos = -0.05,
                 #labels =c("-5", "","","-2","", "0", "","+2","","", "+5", "","","","", "+10"))}
                 labels =c("-5","-2", "0", "+2", "+5","+10"), 
                 cex.axis = talle_nombres_gris)
            axis(1, at = coordinates[c(4, 11)], tick = F, pos = decalage_bas, labels = c("Deletions", "Duplications"), 
                 cex.axis = taille_text_gris, col.axis = "#808080")
          }
        } # adds x axis
        if (plotcounter == 1){
          # Add LEGEND
          text(0.5, 0.85, "Deleterious", adj=0, cex=2, font = 2, col="white")
          text(0.5, 0.34, "Neutral",     adj=0, cex=2, font = 2, col="white")
          text(0.5, 0.11, "Beneficial",  adj=0, cex=2, font = 2, col="white")
        }
        if (draw_box){box("figure", col="forestgreen"); box(which="plot", col="red")}
        mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.3, at = 0 , outer = FALSE, cex = 1.5, font =2)
        cat (" - Completed.\n")
      }# for (mut_type
    }# for (topology
  }# DRAW WHOLE FIGURE
  
  {# ADD TEXT
    mtext('Regulatory mutations'  , side = 3, line = 0.2, at = 0.333/2, outer = TRUE, cex = 1.5, font = 2)
    mtext('Coding mutations'      , side = 3, line = 0.2, at = 0.5    , outer = TRUE, cex = 1.5, font = 2)
    mtext('Deletion / Duplication', side = 3, line = 0.2, at = 1.666/2, outer = TRUE, cex = 1.5, font = 2)
    
    mtext('Highly Connected', side = 2, line = 3.8, at = 1.666/2, outer = TRUE, col="red3"       , font = 2, cex=1.3)
    mtext("Random",           side = 2, line = 3.8, at = 0.5    , outer = TRUE, col="forestgreen", font = 2, cex=1.3)
    mtext('Scale-Free',       side = 2, line = 3.8, at = 0.333/2, outer = TRUE, col="blue3"      , font = 2, cex=1.3)
    
    taille_text_noir = 1.2
    
    mtext("Frequency", side = 2, line = 2.2, at = 1.666/2 , outer = TRUE, cex = taille_text_noir) #0.7
    mtext("Frequency", side = 2, line = 2.2, at = 0.5     , outer = TRUE, cex = taille_text_noir)
    mtext("Frequency", side = 2, line = 2.2, at = 0.333/2 , outer = TRUE, cex = taille_text_noir)
    
    descente_text = 3.8
    mtext('Mutation size (Regulation)', side = 1, line = descente_text, at = 0.333/2, outer = TRUE, cex = taille_text_noir) #0.7
    mtext('Mutation size (Activity)', side = 1, line = descente_text, at = 0.5    , outer = TRUE, cex = taille_text_noir)
    mtext('Number of genes'           , side = 1, line = descente_text, at = 1.666/2, outer = TRUE, cex = taille_text_noir)
  }# ADD TEXT
  dev.off() 
#} # FULL PDF FIGURE


################################################################
################################################################
################################################################
## PLOT FIGURE 5 - PLEIOTROPY
################################################################
################################################################
################################################################
### BASED ON SCRIPT 182:
# If needed, load the allmutations file
# allmutations2 = read.csv("Extracted_data/allmutations_20250618224312_001_TUTO_SIMUS.csv")[, -1]
# colnames(allmutations)=cnames

{## PRE-TREATMENT
  effect_class_tresh = rev(c(0.1, 0.01, 0.001, -0.001, -0.01, -0.1))
  effect_class= rev(c("BENEF3", "BENEF2", "BENEF1", "NEUTR", "DELET1", "DELET2", "DELET3"))
  effect_class_color = rev(c(colorRampPalette(c("#066400","#BFBFBF", "#831D01"))(7)))
  allmutations$fit_effect <- assign_category(allmutations$fit_delta)
  allmutations = allmutations[allmutations$notes != "NO MUTATION",]
} ;   # pre-treatment

# { # LAUNCH AND SAVE PDF
#   width = 23 # unit is cm
#   height =  20 # unit is cm
#   pdf(file = paste0(folder, "/outputs/Rplot", format(Sys.time(), "%Y%m%d%H%M%S"), "_", batch, ".pdf"), 
#       width = width/cmtoin, height = height/cmtoin)
  
  { # DRAW WHOLE FIGURE
    # LAYOUT
    par(oma = c(3, 5.7, 3, 0)) # Outer (overall) MArgin
    mar_plot_pleio = c(0.2, 0.2, 2.5, 0.5)+0.1 # plot inside MARgins
    mar_plot_cis   = c(0.1, 0.2, 0.1, 0.5)+0.1   # plot inside MARgins
    layout_matrix <- matrix(c(1,3,5,2,4,6,7,9,11,8,10,12,13,15,17,14,16,18), nrow = 6, byrow = TRUE)
    layout(layout_matrix, heights = rep(c(4,0.4), 9))  # heights are ratios
    #layout.show(18)
    draw_box = F #for box("figure", col="forestgreen)
    # ESTHETICS
    color_cis = adjustcolor("#EDD405", 0.6) #yellow
    color_cis_grey = "#DBDBDB"
    barplot_space = 0.05 # default 0.2
    barplot_border_color = NA #"white" # default black
    segment_color = "white"
    # PARAMETERS
    pleio_levels=0:10
    tout_a_100 = F # si on met tout à 100, alors tous les bars sont entre 0 et 100. Sinon, c'est relatif
    include_minus_values = T #include nnot only 0.5 but -0.5 too - and not only DUP 1, but also DEL 1
    degage_DUP = T # en fait c'est les DEL qu'on degage (si degage_DUP = T alors on dégage les DEL)
    focus_genes = "ALL" # "SELECTED" "FREE" # "ALL" # pour la sup figure
    
    ######### START PLOT ##################
    plotcounter = 0
    for (topology in c("HIGHCO", "RANDOM", "SCALEF")){
      #topology = "HIGHCO"
      pool_topology = allmutations[allmutations$topology==topology,]
      
      for (mut_type in c("REG", "COD", "DUP")){
        #mut_type = "REG"
        plotcounter = plotcounter+1
        #plotcounter = 1
        cat(paste0(topology, " - ", mut_type, " - "))
        pool_mut_type = pool_topology[pool_topology$mut_type==mut_type,]
        #Find the right muteff column and value
        set_muteffs= c(0.5,          0.5,         1               )
        muteff_var = c("reg_muteff", "cod_muteff", "dupdel_number")[match(mut_type, c("REG", "COD", "DUP"))]
        muteff_val = set_muteffs[match(mut_type, c("REG", "COD", "DUP"))]
        # pool for muteff = 0.5 or dup =1
        if(include_minus_values){imv = -1} else {imv=1}
        if(degage_DUP){if(mut_type=="DUP"){imv=1}} # ICI ON EMPECHE LES DELETIONS
        pool_filter = pool_mut_type[(pool_mut_type[,muteff_var]== muteff_val     |
                                       pool_mut_type[,muteff_var]== muteff_val*imv ),]
        pool_filter$CIS = pool_filter$pleiotropy * pool_filter$Expr_effect_cisness
        if (focus_genes=="SELECTED"){focus_genes_list = c(1,2,3,4,5 ); cat("**SELECTED GENES** " )}
        if (focus_genes=="FREE"    ){focus_genes_list = c(6,7,8,9,10); cat("**FREE GENES** ")}
        if (focus_genes=="ALL"){focus_genes_list = c(1,2,3,4,5,6,7,8,9,10)}
        
        pool_filter = pool_filter[(pool_filter[,"i"]            %in% focus_genes_list    |
                                     pool_filter[,"dupdel_genes"] %in% focus_genes_list),]
        
        #Setup empty dataframes for results
        # PLEIOTROPY
        bilan_pool_pleio = data.frame(matrix(ncol = length(pleio_levels), nrow = length(effect_class)))
        colnames(bilan_pool_pleio) = pleio_levels
        rownames(bilan_pool_pleio) = rev(effect_class)
        #CIS / TRANS
        bilan_pool_cis = data.frame(matrix(ncol = length(pleio_levels), nrow = 1))
        colnames(bilan_pool_cis) = pleio_levels
        rownames(bilan_pool_cis) = "cisness"
        
        #Compute and fill in the dataframe
        for (used_pleio in colnames(bilan_pool_pleio)){ # 0:10
          # used_pleio = "0"
          cat(paste0(sprintf("%02d", as.integer(used_pleio)), " "))
          pool = pool_filter[pool_filter$pleiotropy == used_pleio,] # column is affected_genes in old allmutations sets and not pleiotropy (recents sets)
          
          # PLEIOTROPY
          for (fit_effect in rownames(bilan_pool_pleio)){ #"NEUTR" "BENEF" "DELET"
            # fit_effect = "NEUTR"
            if (tout_a_100){
              bilan_pool_pleio[fit_effect, used_pleio] = sum(pool$fit_effect == fit_effect)/nrow(pool) # Everybody at 100
            }else{
              bilan_pool_pleio[fit_effect, used_pleio] = sum(pool$fit_effect == fit_effect)/nrow(pool_filter) # See relative numbers
            } # end if tout à 100
          } # end for fit_effect
          
          # CIS / TRANS
          bilan_pool_cis["cisness", used_pleio] = mean(pool$CIS)
          } # end for used_pleio
        cat(paste0("- Done (", plotcounter,").\n"))
        
        # PLOT PLEIOTROPY
        par(mar=mar_plot_pleio)
        if (tout_a_100 == F){
          ylim = c(0,0.42)
          if (plotcounter==7){ylim = c(0,0.6)}
          barplot(as.matrix(bilan_pool_pleio), col=rev(effect_class_color), border = NA, xaxt = "n", yaxt = "n", ylim=ylim, space = barplot_space)
          barplot(colSums(as.matrix(bilan_pool_pleio)), add = T, col="NA", yaxt = "n", ylim=ylim, names.arg = NA, space = barplot_space, border=barplot_border_color)
          # y axes
          if (sum(plotcounter==c(1,4)) == 1){
            #barplot(colSums(as.matrix(bilan_pool_pleio)), border=NA, col=NA, xaxt = "n", add = T)
            axis(side=2, at=seq(0, 0.4, by=0.1), labels=c("", "0.1", "0.2", "0.3", "0.4"), cex.axis =1.5)
          }
          if (sum(plotcounter==c(2,5,6,8,9)) == 1){
            axis(side=2, at=seq(0, 0.4, by=0.1), labels=c("", "", "", "", 0.4), cex.axis =1.5)}
          if (plotcounter==3){
            axis(side=2, at=seq(0, 0.4, by=0.1), labels=c("", "", "", "", ""))}
          if (plotcounter==7){
            axis(side=2, at=c(0, 0.1, 0.2, 0.3, 0.4), labels=c("", "", "0.2", "", "0.4"), cex.axis =1.5)}}
        
        if (tout_a_100 == T){
          mar_plot_pleio2 = mar_plot_pleio + c(0, 0, 0.4, 0.4)
          mar_plot_cis2   = mar_plot_cis   + c(0, 0, 0.0, 0.4)
          par(mar=mar_plot_pleio2)
          barplot(as.matrix(bilan_pool_pleio), col=rev(effect_class_color), border = rev(effect_class_color), xaxt = "n", yaxt = "n", ylim=c(0,1), space = barplot_space, names.arg = NULL)
          #barplot(colSums(as.matrix(bilan_pool_pleio)), add = T, col="NA", yaxt = "n", ylim=c(0,1), space = barplot_space, border = barplot_border_color, names.arg = NULL)
          # y axes
          if (sum(plotcounter==c(1,4,7)) == 1){      axis(side=2, at=seq(0, 1, by=0.2), labels=c("", "0.2", "0.4", "0.6", "0.8", "1"))}
          if (sum(plotcounter==c(2,3,5,6,8,9)) == 1){axis(side=2, at=seq(0, 1, by=0.2), labels=rep("", 6))}}
        mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.3, at = 0 , outer = FALSE, font=2, cex = 1.2)
        if (draw_box){box("figure", col="forestgreen"); box(which="plot", col="red")}
        
        if (plotcounter == 1 & tout_a_100 == F){
          # Add LEGEND
          my_cex = 1.2
          my_font=2
          remov=0.042
          text(0.1, 0.37-remov*0, "Deleterious", adj=0, cex=1.4, font = 2, col=effect_class_color[2])
          text(0.1, 0.37-remov*1, "Neutral",     adj=0, cex=1.4, font = 2, col=effect_class_color[4])
          text(0.1, 0.37-remov*2, "Beneficial",  adj=0, cex=1.4, font = 2, col=effect_class_color[6])}
        
        if (plotcounter == 9 & tout_a_100 == F){
          # ADD LEGEND
          par(family = "Courier")
          remov=0.03
          my_cex = 1.2
          my_font=2
          text(midpoints[11]+0.5, 0.4-remov*0, expression("         " * Delta * w * " < -0.1  ") , adj=1, col=effect_class_color[1], cex=my_cex, font=my_font)
          text(midpoints[11]+0.5, 0.4-remov*1, expression("  -0.1 < " * Delta * w * " < -0.01 ") , adj=1, col=effect_class_color[2], cex=my_cex, font=my_font)
          text(midpoints[11]+0.5, 0.4-remov*2, expression(" -0.01 < " * Delta * w * " < -0.001") , adj=1, col=effect_class_color[3], cex=my_cex, font=my_font)
          text(midpoints[11]+0.5, 0.4-remov*3, expression("-0.001 < " * Delta * w * " <  0.001") , adj=1, col=effect_class_color[4], cex=my_cex, font=my_font)
          text(midpoints[11]+0.5, 0.4-remov*4, expression(" 0.001 < " * Delta * w * " <  0.01 ") , adj=1, col=effect_class_color[5], cex=my_cex, font=my_font)
          text(midpoints[11]+0.5, 0.4-remov*5, expression("  0.01 < " * Delta * w * " <  0.1  ") , adj=1, col=effect_class_color[6], cex=my_cex, font=my_font)
          text(midpoints[11]+0.5, 0.4-remov*6, expression("   0.1 < " * Delta * w * "         ") , adj=1, col=effect_class_color[7], cex=my_cex, font=my_font)
          par(family = "")}
        
        # PLOT CIS/TRANS
        if (tout_a_100 == T){par(mar=mar_plot_cis2)}else{par(mar=mar_plot_cis)}
        if (mut_type!="DUP"){
          plotable_data_cis = c(1, as.numeric(bilan_pool_cis[1,])[2:11])
          color_cis_array = c(color_cis_grey, rep(color_cis, 10))
          midpoints = barplot(plotable_data_cis, col=color_cis_array, border = NA, axes = F, space = barplot_space, names.arg = NA) #, names.arg = c(0:10)
          barplot(rep(1, 11), col = NA, add=T, names.arg = NA, axes = F, space = barplot_space, border=barplot_border_color)
          segments(midpoints[1]-0.5, 0, midpoints[1]+0.5, 1, col = segment_color)
          if (sum(plotcounter==c(1,4,7)) == 1){axis(side = 2, at = c(0,1), labels = c(0,1))
          } else {axis(side = 2, at = c(0,1), labels = c("", ""))}
        } else { # if DUP
          midpoints = barplot(rep(1, 11), col = color_cis_grey, axes = F, space = barplot_space, border=NA, names.arg = NA)
          barplot(rep(1, 11), col = NA, axes = F, names.arg = NA, space = barplot_space, border=NA, add=T)
          axis(side = 2, at = c(0,1), labels = c("", ""))
          for (i in c(midpoints)){
            segments(i-0.5, 0, i+0.5, 1, col = segment_color)      
          } # if (mut_type!="DUP")
        } # else if DUP or not
        text(midpoints, 0.5, labels = 0:10, font = 2, col="#696969", cex=1.2)
        if (draw_box){box("figure", col="forestgreen"); box(which="plot", col="red")}
      } # for (mut_type in c("REG", "COD", "DUP"))
    } # for (topology in c("HIGHCO", "RANDOM", "SCALEF"))
    if (focus_genes=="SELECTED"){cat("ATTENTION - focus_genes is set on SELECTED - genes under selection only - ATTENTION")}
    if (focus_genes=="FREE"    ){cat("ATTENTION - focus_genes is set on FREE - genes not-under selection only - ATTENTION")}
    
  } # DRAW WHOLE FIGURE
  
  {# TEXT
    mtext(paste0("Regulatory mutations (+/-", set_muteffs[1], ")"), side = 3, line = 0.7, at = 0.3333*0.5    , outer = TRUE, cex = 1.2, font=2)
    mtext(paste0("Coding mutations (+/-",     set_muteffs[2], ")"), side = 3, line = 0.7, at = 0.3333*1.5    , outer = TRUE, cex = 1.2, font=2)
    mtext(paste0("Duplications (+",           set_muteffs[3], ")"), side = 3, line = 0.7, at = 0.3333*2.5    , outer = TRUE, cex = 1.2, font=2)
    mtext('Highly Connected', side = 2, line = 3.9, at = 1.666/2, outer = TRUE, col="red3"       , font = 2, cex=1.2)
    mtext("Random",           side = 2, line = 3.9, at = 0.5    , outer = TRUE, col="forestgreen", font = 2, cex=1.2)
    mtext('Scale-Free',       side = 2, line = 3.9, at = 0.333/2, outer = TRUE, col="blue3"      , font = 2, cex=1.2)
    mtext('Pleiotropy', side = 1, line = 0.7, at = 0.3333*0.5    , outer = TRUE, cex = 1.1)
    mtext('Pleiotropy', side = 1, line = 0.7, at = 0.3333*1.5    , outer = TRUE, cex = 1.1)
    mtext('Pleiotropy', side = 1, line = 0.7, at = 0.3333*2.5    , outer = TRUE, cex = 1.1)
    if (tout_a_100 == F){
      mtext("Density", side = 2, line = 2.3, at = 1.666/2 , outer = TRUE, cex = 0.9)
      mtext("Density", side = 2, line = 2.3, at = 0.5     , outer = TRUE, cex = 0.9)
      mtext("Density", side = 2, line = 2.3, at = 0.333/2 , outer = TRUE, cex = 0.9)}
    if (tout_a_100 == T){
      mtext("Frequency", side = 2, line = 2.2, at = 1.666/2 , outer = TRUE, cex = 0.7)
      mtext("Frequency", side = 2, line = 2.2, at = 0.5     , outer = TRUE, cex = 0.7)
      mtext("Frequency", side = 2, line = 2.2, at = 0.333/2 , outer = TRUE, cex = 0.7)}
    mtext("pba. cis", side = 2, line = 1.5, at = 1.666/2-0.15, outer = TRUE, cex = 0.8, las=1) #las = 1 pour horizontal text
    mtext("pba. cis", side = 2, line = 1.5, at = 0.5    -0.15, outer = TRUE, cex = 0.8, las=1)
    mtext("pba. cis", side = 2, line = 1.5, at = 0.333/2-0.15, outer = TRUE, cex = 0.8, las=1)
    mtext("0", side = 2, line = 0.65, at = 1.666/2-0.129, outer = TRUE, cex = 1)#, col="red")
    mtext("0", side = 2, line = 0.65, at = 0.5    -0.129, outer = TRUE, cex = 1)#, col="red")
    mtext("0", side = 2, line = 0.65, at = 0.333/2-0.129, outer = TRUE, cex = 1)#, col="red")
    
  }
  dev.off()
# } # LAUNCH AND  SAVE PDF

################################################################
################################################################
################################################################
## PLOT FIGURE 6 - MUTATION PROPERTIES
################################################################
################################################################
################################################################
## Based on SCRIPT 171

{# Define different classes for effect on fitness.
  effect_class_tresh = rev(c(0.1, 0.01, 0.001, -0.001, -0.01, -0.1))
  effect_class  = rev(c("BENEF3", "BENEF2", "BENEF1", "NEUTR", "DELET1", "DELET2", "DELET3"))
  effect_class_color = rev(c(colorRampPalette(c("#066400","#989797", "#831D01"))(7)))
  allmutations$fit_effect <- assign_category(allmutations$fit_delta)
}

# REMOVE NO MUTATIONS # Needed parce qu'on veut pas biaiser nos data (?) - on a pas besoin de la barre à zero
allmutations = allmutations[allmutations$notes != "NO MUTATION",]
# Remove DUP DEL en fait on en a pas besoin
allmutations = allmutations[allmutations$mut_type != "DUP",]
allmutations = allmutations[allmutations$mut_type != "DEL",]
  
############# PLOT ##########################
effect_class
effect_class_color
effect_class_color2 = c(t(outer(effect_class_color, c("",""), paste, sep="")))
mut_types_test = c("REG", "COD") #, "DUP", "DEL")
pleio_levels = 0:10
cex_mtext = 1
effect_class2 = effect_class
cex_mtext = 1.2
effect_class2 = c("---", "--", "-", "0", "+", "++", "+++")

#####################
#resetplot() # also resets cex_mtext to 1 (default)

chosentopologies = "SCALEF"
#chosentopologies = c("HIGHCO", "RANDOM", "SCALEF")

plot5 = F  ; if(plot5){p5=1}else{p5=0}
plotsize = F ; if(plotsize){psize=1}else{psize=0}
draw_box = F
titles = F

nb_topo = length(chosentopologies)
nb_plot = 3+p5+psize

# width = 11*nb_topo # unit is cm
# height =  6*nb_plot+1 # unit is cm
# pdf(file = paste0("Rplot", format(Sys.time(), "%Y%m%d%H%M%S"), "_", width, "x", height, ".pdf"),
#     width = width/cmtoin, height = height/cmtoin)

{ # LAUNCH FIGURE GENERATION ###################################################
  par(mfcol=c(nb_plot,nb_topo))
  # par(mfrow=c(3,4))
  plotcounter = 0
  cex_mtext2 = 0.68
  par(oma = c(0,1,2,0))
  par(mgp=c(2.1, 1, 0))
  par(mar=c(3,4,1.7,1))
  old_mar = par("mar")
  old_mgp = par("mgp")
  line1 = 0.4
  ##########
  
  for (topology in chosentopologies){ # start for (topology in ...)
    
    pool_topology = allmutations[allmutations$topology==topology,]
    #Check
    nrow(pool_topology[pool_topology$mut_type=="REG",])
    nrow(pool_topology[pool_topology$mut_type=="COD",])
    
    # COLORS
    regcod_colors = c("#FFE9B3", "#B3E4FF") #yello et blue
    regcod_colors  = c(adjustcolor("#FF9830", 0.3), adjustcolor("grey", 0.5)) # orange et gris
    regcod_colors2 = c(adjustcolor("#FF9830", 0.8), adjustcolor("grey", 0.7)) # orange et gris
    regcod_colors  = rev(c(adjustcolor("#2B799E", 0.4), adjustcolor("grey", 0.5))) # rev(teal et gris
    regcod_colors2 = rev(c(adjustcolor("#267FA8", 0.8), adjustcolor("grey", 0.7))) # rev(teal et gris
    
    ##############################################################
    ##############################################################
    # FIRST TAKE OUT DATA # POUR PLOT 1 ET PLOT 5
    #Setup empty dataframe for results
    bilan_pool_regcod = data.frame(matrix(ncol = length(effect_class)+1, nrow = length(mut_types_test)))
    colnames(bilan_pool_regcod) = c("ALL", effect_class)
    rownames(bilan_pool_regcod) = mut_types_test
    
    # FILL COLUMN FOR ALL 
    effect_cat = "ALL"
    for (mut_type in mut_types_test){
      bilan_pool_regcod[mut_type,effect_cat] = nrow(pool_topology[pool_topology$mut_type==mut_type,])
    }
    # FILL OTHER COLUMNS
    for (effect_cat in effect_class){
      for (mut_type in mut_types_test){
        bilan_pool_regcod[mut_type,effect_cat] = nrow(pool_topology[pool_topology$fit_effect==effect_cat & pool_topology$mut_type==mut_type,])
      }
    }
    # pour PLOT 5
    bilan_pool_regcod_distrib = bilan_pool_regcod
    # pour avoir un pourcentage:
    column_sums = colSums(bilan_pool_regcod)
    bilan_pool_regcod = sweep(bilan_pool_regcod, 2, column_sums, "/") # column operation
    bilan_pool_regcod
    
    
    ##############################################################
    ####### PLOT 5 - Density distribution
    ##############################################################
    par(mar = old_mar+c(0.5,0,0,0.2))
    par(mgp = old_mgp)
    
    if (plot5){
      
      bilan_pool_regcod_distrib
      my_distrib = as.vector(unlist(bilan_pool_regcod_distrib[,-1] , use.names = FALSE))
      my_distrib = my_distrib/sum(my_distrib)
      # Let's add a fake bar to push things on the side.
      my_distrib = c(mean(my_distrib), my_distrib)
      my_barplot = barplot(my_distrib, 
                           col=c("white",rep(regcod_colors2,7)),
                           border = F, #c(F,T,T,T,T,T,T,T,T,T,T,T,T,T,T,T),
                           space = c(0, 2.5, rep(c(0.05, 0.5), 10))[1:15],
                           ylab = "Density", axes = F)
      axis(2, at = c(0,0.05, 0.1, 0.15, 0.2), labels = c(0, 0.05, 0.1, 0.15, 0.2))
      mids = colSums(matrix(my_barplot[-1], nrow = 2, ncol = 7, byrow = F))/2
      
      #axis(1, at = my_barplot[-1], labels = rep(c("reg", "cod"), 7), las=3, tick = F, line = 0-0.5)
      
      fit_labels = c("-0.1>", "-0.01>", "-0.001>", expression(Delta * w), ">0.001", ">0.01", ">0.1")
      for (i in 1:8){
        mtext(fit_labels[i] , side=1, line=line1, at = mids[i], font = 2, cex = cex_mtext2, col = effect_class_color[i])
      }
      
      plotcounter = plotcounter + 1 ; draw_box_check()
      mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.5, at = 0 , outer = FALSE, cex = 1, font =2)
      
      # box()
      # abline(v=c((my_barplot[3]+my_barplot[4])/2, 
      #            (my_barplot[5]+my_barplot[6])/2,
      #            (my_barplot[7]+my_barplot[8])/2,
      #            (my_barplot[9]+my_barplot[10])/2,
      #            (my_barplot[11]+my_barplot[12])/2,
      #            (my_barplot[13]+my_barplot[14])/2))
      abline(h=0, col="grey")
      
      text(x = 0, y = 0.20, "Regulatory", col=make_darker_color(regcod_colors2[1]), cex=1.2, adj=0)
      text(x = 0, y = 0.175, "Coding",     col=make_darker_color(regcod_colors2[2]), cex=1.2, adj=0)
      
      line2 = 1.8
      mtext("Deleterious", side=1, line=line2, at = mids[2], font = 2, cex = 0.9, col = effect_class_color[2])
      mtext("Neutral",     side=1, line=line2, at = mids[4], font = 2, cex = 0.9, col = effect_class_color[4])
      mtext("Beneficial",  side=1, line=line2, at = mids[6], font = 2, cex = 0.9, col = effect_class_color[6])
      
    } # if plot5
    
    ##############################################################
    ####### PLOT 1 - REG / COD
    ##############################################################
    par(mar = old_mar) ; par(mgp = old_mgp)
    
    if (!plot5){par(mar = old_mar+c(0.5,0,0,0.2))}
    
    mut_types_test
    
    main = ""
    
    spaces = c(0, 0.35 ,0,0,0,0,0,0)
    if (titles){main = paste0("Regulatory & Coding: ", topology)}
    mids = barplot(as.matrix(bilan_pool_regcod), col = regcod_colors, space = spaces, border = "white", 
                   main = main, ylab="Frequency", names.arg = rep("", 8))
    abline(h=.5, lty=2, col="#6F6F6F")
    
    plotcounter = plotcounter + 1 ; draw_box_check()
    mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.5, at = 0 , outer = FALSE, cex = 1, font =2)
    
    
    text(x = mids[1], y = .25, "Regulatory", cex = 1, col = make_darker_color(regcod_colors[1], 80), srt = 90)
    text(x = mids[1], y = .75, "Coding"    , cex = 1, col = make_darker_color(regcod_colors[2], 80), srt = 90)
    
    mtext("ALL"                , side=1, line=line1, at = mids[1], font = 1, cex = cex_mtext2)
    mtext("-0.1>"              , side=1, line=line1, at = mids[2], font = 1, cex = cex_mtext2, col = effect_class_color[1])
    mtext("-0.01>"             , side=1, line=line1, at = mids[3], font = 1, cex = cex_mtext2, col = effect_class_color[2])
    mtext("-0.001>"            , side=1, line=line1, at = mids[4], font = 1, cex = cex_mtext2, col = effect_class_color[3])
    mtext(expression(Delta * w), side=1, line=line1, at = mids[5], font = 1, cex = cex_mtext2, col = effect_class_color[4])
    mtext(">0.001"             , side=1, line=line1, at = mids[6], font = 1, cex = cex_mtext2, col = effect_class_color[5])
    mtext(">0.01"              , side=1, line=line1, at = mids[7], font = 1, cex = cex_mtext2, col = effect_class_color[6])
    mtext(">0.1"               , side=1, line=line1, at = mids[8], font = 1, cex = cex_mtext2, col = effect_class_color[7])
    
    if (!plot5){
      line2 = 1.8
      mtext("Deleterious", side=1, line=line2, at = mids[3], font = 2, cex = 0.9, col = effect_class_color[2])
      mtext("Neutral",     side=1, line=line2, at = mids[5], font = 2, cex = 0.9, col = effect_class_color[4])
      mtext("Beneficial",  side=1, line=line2, at = mids[7], font = 2, cex = 0.9, col = effect_class_color[6])
    }
    
    ##############################################################
    ####### PLOT 2 - PLEIO
    ##############################################################
    par(mar = old_mar) ; par(mgp = old_mgp)
    pleio_levels
    pleio_color_main = "#40015A" # violet un peu pétant
    pleio_color_main = "#533774" # violet plus doux
    pleio_colors = colorRampPalette(c("white", pleio_color_main))(length(pleio_levels))
    #Setup empty dataframe for results
    bilan_pool_pleio = data.frame(matrix(ncol = length(effect_class)+1, nrow = length(pleio_levels)))
    colnames(bilan_pool_pleio) = c("ALL", effect_class)
    rownames(bilan_pool_pleio) = pleio_levels
    
    # FILL COLUMN FOR ALL 
    effect_cat = "ALL"
    for (pleio in pleio_levels){
      bilan_pool_pleio[pleio+1,effect_cat] = nrow(pool_topology[pool_topology$pleiotropy==pleio,])
    }
    # pour avoir un pourcentage:
    bilan_pool_pleio[,effect_cat] = bilan_pool_pleio[,effect_cat] / sum(bilan_pool_pleio[,effect_cat])
    
    
    for (effect_cat in effect_class){
      for (pleio in pleio_levels){
        bilan_pool_pleio[pleio+1,effect_cat] = nrow(pool_topology[pool_topology$fit_effect==effect_cat & pool_topology$pleiotropy==pleio,])
      }
      # pour avoir un pourcentage:
      bilan_pool_pleio[,effect_cat] = bilan_pool_pleio[,effect_cat] / sum(bilan_pool_pleio[,effect_cat])
    }
    bilan_pool_pleio ; "" ; colSums(bilan_pool_pleio)
    
    spaces = c(0, 0.35 ,0,0,0,0,0,0)
    if (titles){main = paste0("Pleiotropy: ", topology)}
    mids = barplot(as.matrix(bilan_pool_pleio), col = pleio_colors, space = spaces, border = "white", 
                   main = main, ylab="Frequency", names.arg = rep("", 8))
    
    plotcounter = plotcounter + 1 ; draw_box_check()
    mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.5, at = 0 , outer = FALSE, cex = 1, font =2)
    
    cumsum_vector = cumsum(c(0, bilan_pool_pleio$ALL))
    intermediate_values <- cumsum_vector[-length(cumsum_vector)] + diff(cumsum_vector) / 2
    pleio_colors_bis = rev(pleio_colors) ; pleio_colors_bis[1:6] = pleio_colors[10]; pleio_colors_bis[7:10] = pleio_colors[1]
    
    for (i in 1:11){
      text(x = mids[1], y = intermediate_values[i], labels = c(0:10)[i], cex = 1, col = pleio_colors_bis[i], srt=0)
    }
    
    # mtext("ALL", side=1, line=1, at = (1-0.5), font = 2, cex = cex_mtext2)
    # for (i in 1:7){
    #   mtext(effect_class2[i], side=1, line=1, at = mids[i+1], col = effect_class_color[i], font = 2, cex = cex_mtext)
    # }
    
    # mtext("Deleterious", side=1, line=line2, at = mids[3], font = 2, cex = cex_mtext2, col = effect_class_color[2])
    # mtext("Neutral",     side=1, line=line2, at = mids[5], font = 2, cex = cex_mtext2, col = effect_class_color[4])
    # mtext("Beneficial",  side=1, line=line2, at = mids[7], font = 2, cex = cex_mtext2, col = effect_class_color[6])
    
    mtext("ALL"                , side=1, line=line1, at = mids[1], font = 1, cex = cex_mtext2)
    mtext("-0.1>"              , side=1, line=line1, at = mids[2], font = 1, cex = cex_mtext2, col = effect_class_color[1])
    mtext("-0.01>"             , side=1, line=line1, at = mids[3], font = 1, cex = cex_mtext2, col = effect_class_color[2])
    mtext("-0.001>"            , side=1, line=line1, at = mids[4], font = 1, cex = cex_mtext2, col = effect_class_color[3])
    mtext(expression(Delta * w), side=1, line=line1, at = mids[5], font = 1, cex = cex_mtext2, col = effect_class_color[4])
    mtext(">0.001"             , side=1, line=line1, at = mids[6], font = 1, cex = cex_mtext2, col = effect_class_color[5])
    mtext(">0.01"              , side=1, line=line1, at = mids[7], font = 1, cex = cex_mtext2, col = effect_class_color[6])
    mtext(">0.1"               , side=1, line=line1, at = mids[8], font = 1, cex = cex_mtext2, col = effect_class_color[7])
    
    
    
    ##############################################################
    ####### PLOT 3 - cis/trans
    ##############################################################
    par(mar = old_mar) ; par(mgp = old_mgp)
    # Make cis/trans computation easier
    pool_topology$CIS=pool_topology$pleiotropy*pool_topology$Expr_effect_cisness
    cis_color = adjustcolor("#EDD405", 0.6) # en fait faudrait que ce soit le même couleur que dans la figure 4bis.
    #Setup empty dataframe for results
    bilan_pool_cis = data.frame(matrix(ncol = length(effect_class)+1, nrow = 1))
    colnames(bilan_pool_cis) = c("ALL", effect_class)
    rownames(bilan_pool_cis) = "pba_CIS"
    
    # Faut retirer les pleio=0 ici
    pool_cistrans = pool_topology[pool_topology$pleiotropy != 0,]
    
    # FILL COLUMN FOR ALL 
    effect_cat = "ALL"
    bilan_pool_cis[1, effect_cat] = mean(pool_cistrans[,]$CIS)
    
    
    for (effect_cat in effect_class){
      bilan_pool_cis[1, effect_cat] = mean(pool_cistrans[pool_cistrans$fit_effect==effect_cat,]$CIS)
    }
    bilan_pool_cis
    
    spaces = c(0, 0.35 ,0,0,0,0,0,0)
    if (titles){main = paste0("Max. cis-effect: ", topology)}
    mids = barplot(as.matrix(bilan_pool_cis), col = cis_color, space = spaces, border = "white", ylim=c(0,1), 
                   main = main, ylab = "Probability", names.arg = rep("", 8))
    
    abline(h=bilan_pool_cis$ALL, lty = 2, col="grey")
    plotcounter = plotcounter + 1 ; draw_box_check()
    mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.5, at = 0 , outer = FALSE, cex = 1, font =2)
    
    # text(x = mids[1], y = bilan_pool_cis$ALL/2+0.04, labels = "probability", cex = 1, col = "black")
    # text(x = mids[1], y = bilan_pool_cis$ALL/2-0.04, labels = "cis-effect" , cex = 1, col = "black")
    
    text(x = mids[1], y = bilan_pool_cis$ALL/2, labels = "probability cis-effect" , cex = 1, 
         col = make_darker_color(cis_color, 100), srt=90)
    
    
    # mtext("ALL", side=1, line=1, at = (1-0.5), font = 2, cex = cex_mtext2)
    # for (i in 1:7){
    #   mtext(effect_class2[i], side=1, line=1, at = mids[i+1], col = effect_class_color[i], font = 2, cex = cex_mtext)
    # }
    
    # mtext("Deleterious", side=1, line=line2, at = mids[3], font = 2, cex = cex_mtext2, col = effect_class_color[2])
    # mtext("Neutral",     side=1, line=line2, at = mids[5], font = 2, cex = cex_mtext2, col = effect_class_color[4])
    # mtext("Beneficial",  side=1, line=line2, at = mids[7], font = 2, cex = cex_mtext2, col = effect_class_color[6])
    
    mtext("ALL"                , side=1, line=line1, at = mids[1], font = 1, cex = cex_mtext2)
    mtext("-0.1>"              , side=1, line=line1, at = mids[2], font = 1, cex = cex_mtext2, col = effect_class_color[1])
    mtext("-0.01>"             , side=1, line=line1, at = mids[3], font = 1, cex = cex_mtext2, col = effect_class_color[2])
    mtext("-0.001>"            , side=1, line=line1, at = mids[4], font = 1, cex = cex_mtext2, col = effect_class_color[3])
    mtext(expression(Delta * w), side=1, line=line1, at = mids[5], font = 1, cex = cex_mtext2, col = effect_class_color[4])
    mtext(">0.001"             , side=1, line=line1, at = mids[6], font = 1, cex = cex_mtext2, col = effect_class_color[5])
    mtext(">0.01"              , side=1, line=line1, at = mids[7], font = 1, cex = cex_mtext2, col = effect_class_color[6])
    mtext(">0.1"               , side=1, line=line1, at = mids[8], font = 1, cex = cex_mtext2, col = effect_class_color[7])
    
    
    
    ##############################################################
    ####### PLOT 4 - Mutation size
    ##############################################################
    par(mar = old_mar) ; par(mgp = old_mgp)
    effect_class
    mut_types_test
    new_mar = old_mar+c(0,1,0,1)
    par(mar = new_mar)
    new_mgp = old_mgp+c(1,1,1)
    par(mgp = new_mgp)
    
    if(plotsize){
      
      library(vioplot) #install.packages("vioplot", type = "binary")
      # vioplot(rnorm(100, mean = 5), rnorm(100, mean = 10), names = c("Group 1", "Group 2"), col = c("gold", "skyblue"), main = "Violin Plot of Two Groups")
      #Setup empty dataframe for results
      bilan_pool_size = data.frame(matrix(ncol = (length(effect_class)+1)*2, nrow = nrow(pool_topology)/2))
      colnames(bilan_pool_size) = c(t(outer(c("ALL", effect_class), mut_types_test, paste, sep="-")))
      
      # FILL COLUMN FOR ALL 
      effect_cat = "ALL"
      for (mut_type in mut_types_test){
        the_values = pool_topology[pool_topology$mut_type==mut_type,]$mutvalue_delta
        bilan_pool_size[[paste0(effect_cat, "-", mut_type)]] = c(the_values, rep(NA, nrow(pool_topology)/2 - length(the_values)))
      }
      
      for (effect_cat in effect_class){
        for (mut_type in mut_types_test){
          the_values = pool_topology[pool_topology$fit_effect==effect_cat & pool_topology$mut_type==mut_type,]$mutvalue_delta
          bilan_pool_size[[paste0(effect_cat, "-", mut_type)]] = c(the_values, rep(NA, nrow(pool_topology)/2 - length(the_values)))
        }
      }
      #boxplot(abs(bilan_pool_size), ylim=c(0,1))
      #vioplot(abs(bilan_pool_size), ylim=c(0,1))
      
      ###### PARAMETERS FOR PLOT: ###
      absolute_values = T
      condensed = T #if TRUE, launch 4B.
      central_point = "mean" # or "median
      space_val = 0.4
      
      if (absolute_values){ ylim = c(-0.02, 1.02) ; bilan_pool_size = abs(bilan_pool_size)
      } else { ylim = c(-1.02, 1.02) }
      
      increments = c(0.3, 0, 0.4+0.5, rep(c(0, space_val), 8))[1:16]
      at_specified = 1:16 + cumsum(increments)
      xlim = c(1,max(at_specified))
      
      if (titles){main = paste0("Mutation size (REG/COD): ", topology)}
      plot(NA, NA, ylim=ylim, xlim=xlim, xaxt = "n", xlab="", 
           ylab="Mutation size (absolute value)", main=main, bty="n")
      box(col = "#8F8F8F", lwd=.5) #grey
      abline(h=.55, col='grey', lty = 2)
      if (!absolute_values){abline(h=c(0, -0.5), col='grey', lty = 2)}
      
      ###### 4.A - (NOT CONDENSED was here before)
      ###### 4.B - 
      par(bty = 'n')
      # vioplot(bilan_pool_size, ylim=c(-1,1), add=T, at = at_specified, border=NA,
      #         col=adjustcolor("white", 0), colMed = adjustcolor(effect_class_color2, 0))
      boxplot(bilan_pool_size, add=T, at = at_specified, col=regcod_colors2, 
              names = rep("", 16), axes=F, lty=1, staplelty = 1, boxwex=.3, 
              whiskcol="white", staplecol = "white")
      par(bty = 'o') # restore default
      
      
      # # Point central
      # reduce_size=0.5
      # if (central_point == "median") {central_point_values = apply(bilan_pool_size, 2, median, na.rm = TRUE)}
      # if (central_point == "mean")   {central_point_values = apply(bilan_pool_size, 2, mean,   na.rm = TRUE)}
      # points(at_specified, central_point_values, col = "white", pch = 20, cex=4)
      # points(at_specified, central_point_values, cex=3-reduce_size)
      # #points(at_specified, central_point_values, col = effect_class_color2, pch = 20, cex=3)
      # points(at_specified, central_point_values, col = regcod_colors2, pch = 20, cex=3-reduce_size)
      # points(at_specified, central_point_values, cex=2-reduce_size)
      
      ###### AXES etc.
      #axis(1, at = at_specified, labels = rep(c("reg", "cod"), 8), las = 2)
      text(x = at_specified+0.1, y = 0-0.02, labels = c("reg", "cod"), srt=90, pos=3)
      at_midpoints <- (at_specified[seq(1, length(at_specified) - 1, by = 2)] + at_specified[seq(2, length(at_specified), by = 2)]) / 2
      #axis(1, at = at_midpoints, labels = paste0("-", c("ALL",effect_class), "-"), tick = F, line = 1, col = c("black",effect_class_color))
      
      
      at_lines <- (at_specified[seq(2, length(at_specified) - 1, by = 2)] + at_specified[seq(3, length(at_specified), by = 2)]) / 2
      abline(v=at_lines[2:7], col="grey")
      abline(v=at_lines[1]-0.2, col="grey")
      abline(v=at_lines[1]+0.2, col="grey")
      
      plotcounter = plotcounter + 1 ; draw_box_check()
      mtext(paste0(LETTERS[plotcounter], "."), side = 3, line = 0.5, at = 0 , outer = FALSE, cex = 1, font =2)
      
      # mtext("ALL", side=1, line=1, at = at_midpoints[1], font = 2, cex = cex_mtext2)
      # for (i in 1:7){
      #   mtext(effect_class2[i], side=1, line=0.75, at = at_midpoints[i+1], col = effect_class_color[i], font = 2, cex = cex_mtext)
      #   # line était 2 avant
      #   #mtext("BENEF", side=1, line=1, at = 0.5, col="red")
      # }
      
      mids = at_midpoints
      
      mtext("ALL"                , side=1, line=line1, at = mids[1], font = 1, cex = cex_mtext2)
      mtext("-0.1>"              , side=1, line=line1, at = mids[2], font = 1, cex = cex_mtext2, col = effect_class_color[1])
      mtext("-0.01>"             , side=1, line=line1, at = mids[3], font = 1, cex = cex_mtext2, col = effect_class_color[2])
      mtext("-0.001>"            , side=1, line=line1, at = mids[4], font = 1, cex = cex_mtext2, col = effect_class_color[3])
      mtext(expression(Delta * w), side=1, line=line1, at = mids[5], font = 1, cex = cex_mtext2, col = effect_class_color[4])
      mtext(">0.001"             , side=1, line=line1, at = mids[6], font = 1, cex = cex_mtext2, col = effect_class_color[5])
      mtext(">0.01"              , side=1, line=line1, at = mids[7], font = 1, cex = cex_mtext2, col = effect_class_color[6])
      mtext(">0.1"               , side=1, line=line1, at = mids[8], font = 1, cex = cex_mtext2, col = effect_class_color[7])
      
    } # end if plotsize
    
    ##############################################################
    ####### FINAL STUFF
    ##############################################################
    
    # Y-titles
    sep = 0.25/2
    midpoints = seq(0,1, length.out = nb_plot+1)[1:(nb_plot)]
    midpoints = midpoints+((midpoints[2]-midpoints[1])/2)
    i = 1
    if(plot5){   mtext("Distribution",   side = 2, line = -0.65, at = rev(midpoints)[i]+0.009, outer = T, font = 2) ; i=i+1}
    mtext("Mutation type",  side = 2, line = -0.65, at = rev(midpoints)[i]+0.009, outer = T, font = 2) ; i=i+1
    mtext("Pleiotropy",     side = 2, line = -0.65, at = rev(midpoints)[i]+0.009, outer = T, font = 2) ; i=i+1
    mtext("Cis-effect",     side = 2, line = -0.65, at = rev(midpoints)[i]+0.009, outer = T, font = 2) ; i=i+1
    if(plotsize){mtext("Mutation size",  side = 2, line = -0.65, at = rev(midpoints)[i]+0.009, outer = T, font = 2) ; i=i+1}
    
    # X-titles (topologies)
    chosentopologies
    topologies_fullnames = c("Highly Connected", "Random", "Scale-Free") 
    tot = length(chosentopologies)
    evenly_spacing <- function(n){return((2 *(1:n)-1)/(2*n))}
    at_coord = evenly_spacing(tot)
    for (i in 1:tot){
      if (tot==1){addnet=" Networks"}else{addnet=""}
      mtext(paste0(topologies_fullnames[match(chosentopologies[i], topologies)], addnet), 
            side = 3, line = 0.7, at = at_coord[i], outer = T, font = 2, 
            col = topocolors[match(chosentopologies[i], topologies)]) 
    }
    
    
    ##############
    
  } # for (topology in ...)
} #FIG 6
dev.off()
